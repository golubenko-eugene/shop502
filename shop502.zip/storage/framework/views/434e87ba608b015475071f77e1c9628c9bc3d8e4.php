<?php $__env->startSection('title', 'Dashboard / Page'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard / Page</h1>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STUDENTS\web-503\OSPanel\domains\shop502\resources\views/admin/page.blade.php ENDPATH**/ ?>