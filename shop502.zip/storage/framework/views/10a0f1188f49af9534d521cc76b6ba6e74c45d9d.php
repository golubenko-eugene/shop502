<?php $__env->startSection('title', 'Add Category'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add Category</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <?php echo Form::model($category, ['url'=>'/admin/categories']); ?>

		<div class="form-group">
			<?php echo Form::label('name', 'Category Name'); ?>

			<?php echo Form::text('name', null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('slug', 'Category Slug'); ?>

			<?php echo Form::text('slug', null, ['class'=>'form-control']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('parent_id', 'Parent Category'); ?>

			<?php echo Form::select('size', $categories, null, ['placeholder' => 'Select parent category', 'class'=>'form-control']); ?>

		</div>
		<div class="input-group">
		   	<span class="input-group-btn">
		     	<a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
		       		<i class="fa fa-picture-o"></i> Choose
		     	</a>
		   	</span>
		   	<input id="thumbnail" class="form-control" type="text" name="filepath">
		</div>
		<img id="holder" style="margin-top:15px;max-height:100px;">

		<?php echo Form::submit('Save', ['class'=>'btn btn-primary']); ?>


    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
	<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
	<script>
		$('#lfm').filemanager('image');
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\STUDENTS\web-503\OSPanel\domains\shop502\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>