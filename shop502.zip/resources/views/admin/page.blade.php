{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Dashboard / Page')

@section('content_header')
    <h1>Dashboard / Page</h1>
@stop


